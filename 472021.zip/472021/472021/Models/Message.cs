﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace _472021.Models
{
    public class Message
    {
        [Key]
        public int MessageId { get; set; }

        public DateTime MessageDate { get; set; }

        public bool IsRead { get; set; }

        public string MessageContent { get; set; }


        public string MessageTypeId { get; set; }
        public MessageType MessageType { get; set; }

        public string AddedByUser { get; set; }
    }
}
