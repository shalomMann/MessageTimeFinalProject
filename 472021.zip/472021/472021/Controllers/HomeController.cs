﻿using _472021.Data;
using _472021.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;


namespace _472021.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {

       

        private ApplicationDbContext context { get; set; }

        private UserManager<IdentityRole> _IdentityRole;
        private UserManager<IdentityUser> _userManager;

        public HomeController(UserManager<IdentityUser> userManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            this.context = context;
            
        }

        public IActionResult DailyMessage()
        {
            var TempUserId = _userManager.GetUserId(HttpContext.User);
            var messages = context.Messages.Where(i => i.AddedByUser == TempUserId).Where(i => i.MessageTypeId == "D").OrderBy(i => i.MessageId).ToList();
            
            return View(messages);
        }

        public IActionResult WeeklyMessage()
        {
            var TempUserId = _userManager.GetUserId(HttpContext.User);
            var messages = context.Messages.Where(i => i.AddedByUser == TempUserId).Where(i => i.MessageTypeId == "W").OrderBy(i => i.MessageId).ToList();

            return View(messages);
        }

        public IActionResult MonthlyMessage()
        {
            var TempUserId = _userManager.GetUserId(HttpContext.User);
            var messages = context.Messages.Where(i => i.AddedByUser == TempUserId).Where(i => i.MessageTypeId == "M").OrderBy(i => i.MessageId).ToList();

            return View(messages);
        }

        public IActionResult YearlyMessage()
        {
            var TempUserId = _userManager.GetUserId(HttpContext.User);
            var messages = context.Messages
                
                .Where(i => i.AddedByUser == TempUserId).Where(i => i.MessageTypeId == "Y").OrderBy(i => i.MessageId).ToList();

            return View(messages);
        }

        public IActionResult EventMessage()
        {
            var TempUserId = _userManager.GetUserId(HttpContext.User);
            var messages = context.Messages.Where(i => i.AddedByUser == TempUserId).Where(i => i.MessageTypeId == "E").OrderBy(i => i.MessageId).ToList();

            return View(messages);
        }

        public IActionResult OneTimeMessage()
        {
            var TempUserId = _userManager.GetUserId(HttpContext.User);
            var messages = context.Messages.Where(i => i.AddedByUser == TempUserId).Where(i => i.MessageTypeId == "O").OrderBy(i => i.MessageId).ToList();

            return View(messages);
        }




       


        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            ViewBag.MessageType = context.MessageTypes.OrderBy(m => m.Name).ToList();
            return View("Edit", new Message());
        }


        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            ViewBag.MessageType = context.MessageTypes.OrderBy(m => m.Name).ToList();
            var message = context.Messages.Find(id);
            var mos = ViewBag.Cook;
            return View(message);
        }

        [HttpPost]
        public IActionResult Edit(Message message)
        {
            if (ModelState.IsValid)
            {

                if (message.MessageId == 0)
                {
                    message.AddedByUser = _userManager.GetUserId(HttpContext.User);
                    context.Messages.Add(message);
                }
                else
                {
                    message.AddedByUser = _userManager.GetUserId(HttpContext.User);
                    context.Messages.Update(message);
                }
                    context.SaveChanges();
                
                if (message.MessageTypeId == "D")
                {
                    return RedirectToAction("DailyMessage", "Home");
                }
                else if (message.MessageTypeId == "W")
                {
                    return RedirectToAction("WeeklyMessage", "Home");
                }
                else if (message.MessageTypeId == "M")
                {
                    return RedirectToAction("MonthlyMessage", "Home");
                }
                else if (message.MessageTypeId == "Y")
                {
                    return RedirectToAction("YearlyMessage", "Home");
                }
                else if (message.MessageTypeId == "E")
                {
                    return RedirectToAction("EventMessage", "Home");
                }
                else
                {
                    return RedirectToAction("OneTimeMessage", "Home");
                }
            }
            else
            {
                ViewBag.Action = (message.MessageId == 0) ? "Add" : "Edit";
                ViewBag.MessageType = context.MessageTypes.OrderBy(m => m.Name).ToList();
                return View(message);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var message = context.Messages.Find(id);
            return View(message);
        }

        [HttpPost]
        public IActionResult Delete(Message message)
        {
            string cook = message.MessageTypeId;

            context.Messages.Remove(message);
            context.SaveChanges();
            if (cook == "D")
            {
                return RedirectToAction("DailyMessage", "Home");
            }
            else if (cook == "W")
            {
                return RedirectToAction("WeeklyMessage", "Home");
            }
            else if (cook == "M")
            {
                return RedirectToAction("MonthlyMessage", "Home");
            }
            else if (cook == "Y")
            {
                return RedirectToAction("YearlyMessage", "Home");
            }
            else if (cook == "E")
            {
                return RedirectToAction("EventMessage", "Home");
            }
            else
            {
                return RedirectToAction("OneTimeMessage", "Home");
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [Authorize(Roles = "Admin")]
        public IActionResult AdminPanel()     
        {
            
            return View();
        }
        [HttpGet]
        public IActionResult AdminEdit()
        {
            ViewBag.Cook = context.BuyOrNots.OrderBy(i => i.Id).ToList();
            return View("AdminEdit", new BuyOrNot());
        }

        [HttpPost]
        public IActionResult AdminEdit(BuyOrNot buyOrNot)
        {
            if (buyOrNot.Id == 0)
            {
                buyOrNot.WhoBought = _userManager.GetUserId(HttpContext.User);
                context.BuyOrNots.Add(buyOrNot);
                return RedirectToAction("IndexFlake", "Home");
            }
            else
            {
                return RedirectToAction("IndexFlake", "Home");
            }
        }



        public IActionResult IndexFlake()
        {
            //var TempUserId = _userManager.GetUserId(HttpContext.User);
            //var cook = context.BuyOrNots.Where(i => i.WhoBought == TempUserId).OrderBy(i => i.Id).ToList();

            //if(cook == null)
            //{
            //   return RedirectToAction("Index", "Home");
            //}
            //else
            //{
                return View();
             // }
            
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }
            
       

    }
}
